function h1Hover(){
    let title = document.getElementById('title1');
    title.style.color = ('yellow');
    title.innerText = ('We are the BEST !!!')
}

function h1Leave(){
    let title = document.getElementById('title1');
    title.style.color = ('white');
    title.innerText = ('My TechShop')
}

function bckgnd(){
    let main = document.getElementsByTagName('main');
    main[0].style.background = ('yellow');
}

function address1(){
    let adr = document.getElementById('adr');
    adr.innerText = ("via XXXXXXX n°XX Roma - Italy PI: XXXXXXXXXXXXXXX email: admin@mytechshop.com");
    adr.style.color = ('#b3b3b3');
}

function address2(){
    let adr = document.getElementById('adr');
    adr.innerText = ("via YYYYYYY n°YY Milano - Italy PI: YYYYYYYYYYYYYYYY email: info@mytechshop.com");
    adr.style.color = ('#00ff00');
}

function overPrice(n){    
    let prices = document.getElementsByClassName('price');
    const randomColor = Math.floor(Math.random()*16777215).toString(16); //16 milioni di colori espresso in hex #FFFFFF    
    prices[n].style.color = ('#'+randomColor);
}

function addClass(){
    let links = document.getElementsByTagName('a');
    for (let i = 0; i < links.length; i++) {
        links[i].classList.add("newclassLink");  
    }   
}

function toggleClass(){
    let imgArr = document.getElementsByClassName('td-img');    
    for (let i = 0; i < imgArr.length; i++) {
        imgArr[i].classList.toggle("td-img1");  
    }   
}

