/*function calcola(){//funzione che calcola il punteggio finale
   let ansOK = document.getElementsByClassName('answerOK')//recupero array di risposte con classe "answerOK"
   let output = document.getElementById('punti')//recupero il campo per mostrare il punteggio
   let punteggio = 0; //inizializzo variabile punteggio  
   for (const OK of ansOK) { //ciclo FOR per ciclare oggetti risposte OK
        if(OK.checked){ //interrogo proprietà "checked" di ogni risposta esatta
            punteggio += 1; //incremento punteggio solo se riscontro risposte ok
        }
   }
   output.value = punteggio; //scrivo punteggio in output
}*/

function calcola(){//funzione che calcola il punteggio finale
   let ansOK = document.getElementsByClassName('answerOK')//recupero array di risposte con classe "answerOK"
   let ansNOK = document.getElementsByClassName('answer')//recupero array di risposte con classe "answer"
   let output = document.getElementById('punti')//recupero il campo per mostrare il punteggio
   let button = document.getElementById('calcBtn')//recupero il pulsante di calcolo
   let punteggio = 0; //inizializzo variabile punteggio  
   for (const OK of ansOK) { //ciclo FOR per ciclare oggetti risposte OK
        if(OK.checked){ //interrogo proprietà "checked" di ogni risposta esatta
            punteggio += 1; //incremento punteggio solo se riscontro risposte ok
        }
   }
   output.value = punteggio; //scrivo punteggio in output

   //formatto proprietà pulsante affinchè si disabiliti sia visivamente sia interattivamente
   //in modo da non ripetere l'output
   button.disabled = true;
   button.style.border = ('1px solid')
   button.style.backgroundColor = ('#9c9c9c') 
   button.style.fontWeight = ('normal')   
   button.innerText = ('executed')
}
