//Esercizio 21
console.log("ESERCIZIO N°21");
let x = "John";
let y = "Doe";
console.log(x+" <> "+y);
console.log(" ");


//Esercizio 22
console.log("ESERCIZIO N°22");
function obj(name,surname,email){//funzione costruttore di obj
    this.nome = name; //"this" rappresenta l'oggetto che sto creando
    this.cognome = surname;
    this.email = email;
}

let obj1 = new(obj); //creo un nuovo oggetto invocando il costruttore
//popolo i campi
obj1.nome = "Jacopo";
obj1.cognome = "Mora";
obj1.email ="jack82acdc@hotmail.it"
//stampo in console
console.log(obj1);
console.log(" ");


//Esercizio 23
console.log("ESERCIZIO N°23");
delete obj1.email;
console.log(obj1);
console.log(" ");

//Esercizio 24
let arrStr = ["str1","str2","str3","str4","str5","str6","str7","str8","str9","str10"]

//Esercizio 25
console.log("ESERCIZIO N°24 e n°25");
//ciclo for-of che itera precedente array e stampa in console 
//ogni stringa presente ad ogni indice
for (const str of arrStr) {
    console.log('Stringa = '+str);
}
console.log(" ");

//Esercizio 26
console.log("ESERCIZIO N°26");
let arrNumRandom = [];//dichiaro array vuoto
for (let i = 0; i < 100; i++) { //ciclo for per 100 volte da 0 a 99
    arrNumRandom[i] = Math.round(Math.random()*1000)//creazione di numero intero casuale da 0 a 1000 compreso per ogni posizione dell'array
}
console.log('Array numeri interi randomici = '+arrNumRandom);
console.log(" ");


//Esercizio 27
console.log("ESERCIZIO N°27");
const NumMaxMin = function(arr){ //creazione funzione
    let NumMin = 0; //inizializzazione variabili 
    let NumMax = 0;
    for (let i = 0; i < arr.length; i++) { //ciclo FOR che spazzola l'array
        if (arr[i] < NumMin){//confronto ed eventuale memorizzazione del valore di ogni posizione se esso è maggiore di quello già memorizzato
            NumMin = arr[i];
        }
        if (arr[i] > NumMax){//confronto ed eventuale memorizzazione del valore di ogni posizione se esso è minore di quello già memorizzato
            NumMax = arr[i];
        }        
    }
    return (NumMin+" e "+NumMax) //restituzione dei due valori MIN e MAX
}

console.log('I numeri Min e Max sono: '+NumMaxMin(arrNumRandom));
console.log(" ");

//Esercizio 28
console.log("ESERCIZIO N°28");
let arrDiArr = [];//dichiaro array vuoto
let arrNumRandom2 = [];//dichiaro array vuoto 
for (let z = 0; z < 5; z++) { //ciclo l'array principale per 5 volte popolando ogni posizione con un array popolato a sua volta mediante un ciclo FOR annidato
    arrNumRandom2 = [];//svuoto il "subarray" ad ogni ciclo di generazione di ogni posizione dell'array principale
    for (let i = 0; i < 10; i++) { //ciclo for per 10 volte da 0 a 9 che popola il subarray
        arrNumRandom2[i] = Math.round(Math.random()*1000)//creazione di numero intero casuale da 0 a 1000 compreso per ogni posizione dell'array
    }
    arrDiArr[z] = arrNumRandom2; //assegno alla posizione corrente dell'array padre, l'array figlio appena generato
}
console.log("di seguito la stampa dell'array 'arrDiArr' contenente per ogni posizione, un altro array di 10 numeri interi casuali");
console.log(arrDiArr);
console.log(" ");


//Esercizio 29
console.log("ESERCIZIO N°29");
//dichiaro 2 array di esempio per il test
let arrA = [1,44,"ciao","help",98,[9,"f"]]; //array di 6 elementi
let arrB = [1,"k",5,"help",98,21,7,[3,4]]; //array di 8 elementi
//creo la funzione per verificare quale array ha più elementi
const longestArr = function(arr1,arr2){
   let arr1IsLongest = arr1.length > arr2.length? true:false;  //operatore ternario su confronto lunghezze array
   if (arr1IsLongest){ //ciclo condizionale in base al risultato dell'operatore ternario
        return("l'array con più ha "+arr1.length+" elementi. Essi sono: "+arr1);//return in caso di TRUE
   } else {
        return("l'array con più ha "+arr2.length+" elementi. Essi sono: "+arr2);//return in caso di FALSE
   } 
}
console.log(longestArr(arrA,arrB));
console.log(" ");

//Esercizio 30
console.log("ESERCIZIO N°30");
//dichiaro 2 array con elementi numerici di esempio per il test
let arrNumA = [0,10,50]; 
let arrNumB = [0,10,50,-100,2,-60]; 
//creo la funzione per verificare quale array ha la somma degli elementi maggiore
const arrSumMag = function(arr1,arr2){
    let SumArr1 = 0;//inizializzo variabili somma di ogni array
    let SumArr2 = 0;
    for (const num of arr1) { //ciclo for sul primo array
        SumArr1 += num; //aggiorno il valore della somma incrementandolo per ogni elemento dell'array
    }
    for (const num of arr2) {
        SumArr2 += num;
    }
    if (SumArr1>SumArr2){ //confronto i due valori somma e prevedo i tre casi possibili
        return("l'array con la somma numerica maggiore è il primo, la somma è "+SumArr1);//caso somma arr1 > somma arr2
    } else if (SumArr1<SumArr2 ){
        return("l'array con la somma numerica maggiore è il secondo, la somma è "+SumArr2);//caso somma arr2 > somma arr1
    } else {
        return("La somma degli elementi è identica per entrambe gli array, la somma è "+SumArr2)//caso somme identiche
    }
}
console.log(arrSumMag(arrNumA,arrNumB));
console.log(" ");

//Esercizio 31
console.log("ESERCIZIO N°31");
console.log("con mouseover sul DIV della lista non ordinata, cambia colore sfondo");
function selCon(){ //dichiaro una funzione che punta all'elemento "container"
    let container = document.getElementById("container");
    container.style.backgroundColor = ("yellow"); //visivamente colora di giallo lo sfondo al passaggio del mouse sul DIV   
}
console.log(" ");
  
//Esercizio 32
console.log("ESERCIZIO N°32");
console.log("con mouseover sulla tabella, cambia colore testo agli elemti <TD>");
function selTD(){ //funzione che recupera gli elementi TD e li inserisce in un array
    let tdArr = document.getElementsByTagName("td");
    for (const td of tdArr) { //itero l'array assegnando uno stile ad ogni TD
        td.style.color = ("blue");  
    }  
}
console.log(" ");


//Esercizio 33
console.log("ESERCIZIO N°33");
console.log("con mouse DOPPIO click sulla tabella, vengono esportati i valori testuali dei tag TD");
function tdTextExport(){ //dichiaro funzione
    const TdText = document.getElementsByTagName("td"); //funzione che recupera gli elementi TD e li inserisce in un array
    for (const td of TdText) { //itero l'array pescando il testo di ogni elemento e stampandolo in Console
        let text = td.innerText;
        console.log(text);
    }
}
console.log(" ");


//Esercizio 34
console.log("ESERCIZIO N°34");
function changeTitleH1(){ 
    const title = document.getElementsByTagName("h1"); //funzione che recupera l'unico elemento h1 della pagina
    title[0].innerText = ("titolo modificato da Esercizio n°34");
}
console.log("con mouseover sul titolo , esso viene cambiato");
console.log(" ");

//Esercizio 35
console.log("ESERCIZIO N°35");
function addRow(){ //dichiaro funzione
    let newRow = document.createElement("tr")//creo elemento TR    
    newRow.innerHTML = "<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td>";//inserisco il codice per creare nuove celle
    const table = document.getElementsByTagName("table"); //funzione che recupera gli elementi TABELLA e li inserisce in un array
    table[0].appendChild(newRow) //aggiungo al primo (e unico) elemento tabella l'elemnto "newRow"
}
console.log("con click su pulsante 'Aggiungi Riga' viene aggiunta una nuova riga");
console.log(" ");

//Esercizio 36
console.log("ESERCIZIO N°36");
function addClassTest(){ //dichiaro funzione
    const arrRows = document.getElementsByTagName("tr");//ottengo array di oggetti TR
    for (const row of arrRows) { //ciclo oggetti dell'array
        row.classList.add("test");//invoco funzione classList "add" per aggiungere la classe ad ogni elemento TR
    }    
}
console.log("con click su pulsante 'Add class .test' si aggiunge la classe '.test' ad ogni TR");
console.log(" ");


//Esercizio 37
console.log("ESERCIZIO N°37");
function bckgndLink(){ //dichiaro funzione
    const arrLink = document.getElementsByTagName("a"); //ottengo un array con dentro gli oggetti "a"
    for (const link of arrLink) { //ciclo oggetti dell'array
        link.style.backgroundColor = ('red');
    } 
}
console.log("con click su pulsante 'Add bckgnd Red' si cambia sfondo ai link");
console.log(" ");

//Esercizio 38
/*
console.log("ESERCIZIO N°38");
window.onload = function(){ //su evento di caricameto pagina lancio la funzione
    console.log('Page loaded')//stampo il mex in console
}
console.log(" ");*/

//Esercizio 39
console.log("ESERCIZIO N°39");
function addLi(){
    let textItem = document.getElementById("newItem").value;
    if (textItem !== ""){
        let newLi= document.createElement("li")//creo elemento item list  
        newLi.innerHTML = textItem;//inserisco il codice per creare nuove celle
        const ul = document.getElementsByTagName("ul"); //funzione che recupera gli elementi "ul" e li inserisce in un array
        ul[0].appendChild(newLi) //aggiungo al primo elemento ul l'elemnto "newLi"        
    } else {
        alert('inserisci il testo da aggiungere in lista!!!')
    }
    textItem.value = ("");//cancello il campo per prossimo inserimento
}
console.log("con click su pulsante 'Aggiungi Riga' si aggiunge un elemento alla lista");
console.log(" ");


//Esercizio 40
console.log("ESERCIZIO N°40");
function eraseList(){
    const ul = document.getElementsByTagName("ul");//ottengo array di tutti gli elementi ul della pagina
    ul[0].innerHTML = (""); //svuoto il codice HTML interno alla lista in prima posizione
}
console.log("con click su pulsante 'Svuota Lista' si elimina tutta la lista");
console.log(" ");


////// EXTRA ///////
//Esercizio 41

console.log("ESERCIZIO N°41");
//il codice è scritto in fondo al documento HTML
console.log("passando sopra i link tabella, si ottiene un alert");
console.log(" ");


//Esercizio 42
console.log("ESERCIZIO N°42");
function hideImg(){ //dichiaro funzione
    const arrImg = document.getElementsByTagName("img"); //ottengo un array con dentro gli oggetti "a"
    for (const Img of arrImg) { //ciclo oggetti dell'array
        Img.style.visibility = ('hidden');
    } 
}
console.log("con click su pulsante 'Nascondi Immagini' sparisce la visibilità delle stesse");
console.log(" ");

//Esercizio 43
console.log("ESERCIZIO N°43");
function toggleTable(){ //dichiaro funzione
    const arrTable = document.getElementsByTagName("table"); //ottengo un array con dentro gli oggetti "table"
    arrTable[0].classList.toggle("tableVisibility");
}
console.log("con click su pulsante 'Nascondi/Mostra Tabella' sparisce/appare la tabella");
console.log(" ");

//Esercizio 44
console.log("ESERCIZIO N°44");
function SummCells(){ //dichiaro funzione
    const arrTd = document.getElementsByTagName("td"); //funzione che recupera gli elementi TD e li inserisce in un array
    let res = document.getElementById("SumCells");//punto alla cella dove inserire il risultato
    let somma = 0;//inizializzo variabile somma
    for (const td of arrTd) { //itero l'array celle
        if (typeof(parseInt(td.innerText) === 'number')){  //se il contnuto è trasformabile in numero          
            somma += parseInt(td.innerText); //aggiorno il valore somma con il numero acquisito ad ogni ciclo
        }
    }
    res.value = somma; //inserisco il valore somma nel campo "value" del risultato
}

console.log("con click su pulsante 'Somma Celle' viene stampata in console la somma delle celle con contenuto numerico");
console.log(" ");

//Esercizio 45
console.log("ESERCIZIO N°45");
function eraseChar(){
    const arrH1 = document.getElementsByTagName("h1")  //ottengo l'array di tag h1
    let str = arrH1[0].innerText //prelevo il testo dal tag h1 in prima posizione
    let strArr = str.split("") //trasformo la stringa in array
    strArr.pop() //elimino l'ultimo indice dall'array
    let str2 = strArr.join("") //trasformo l'array di nuovo in stringa
    arrH1[0].innerText = str2 //assegno la stringa modificata alla proprietà "innerText" del tag h1
}
console.log("con click su TITOLO H1 viene tolta l'ultima lettera del testo");
console.log(" ");

//Esercizio 46

console.log("ESERCIZIO N°46");
//il codice è scritto in fondo al documento HTML
console.log("cliccando su un TD in tabella, questo cambia colore di sfondo");
console.log(" ");

//Esercizio 47
console.log("ESERCIZIO N°47");

function eraseTd(){
    const arrTd = document.getElementsByTagName("td"); //recupero gli elementi TD e li inserisce in un array
    const arrTr = document.getElementsByTagName("tr");//recupero gli elementi TR e li inserisco in un array
    let NumMax = arrTd.length - 1; //inizializzo limite di generazione numeri Random = a numero di TD trovati
    let NumRandom = Math.round(Math.random()*NumMax);//generazione di numero intero casuale da 0 a NumMax (numero massimo di TD)

    //siccome TD è child di TR ma non so in quale TR si trova, ho fatto un ciclo FOR che spazzola i TR in cerca del child di indice "NumRandom"
    //con il ciclo TRY/CATCH risolvo l'errore di elemento non trovato in caso il TD di indice "NumRandom" non fosse nel TR iesimo e
    //quindi avremmo un errore. Il CONTINUE fa appunto ripartire il ciclo FOR in caso di errore 
    for (let i = 0; i < arrTr.length; i++) {      
        try {
            arrTr[i].removeChild(arrTd[NumRandom]);//se l'elemento TD di indice "NumRandom" si trova nel TR iesimo, viene rimosso
        } catch (error) {
            continue
        }
    }      
}
console.log("con click su 'ERASE TD' viene eliminato un TD casuale della tabella");
console.log(" ");

//Esercizio 48
console.log("ESERCIZIO N°48");
console.log("eseguito in CSS");
console.log(" ");

//Esercizio 49
console.log("ESERCIZIO N°49");

function newTable(){    
  let newTable = document.createElement('table') //crea nuovo elemento tabella
  let body = document.getElementsByTagName('body') //recupera l'elemento body
  let footer = document.getElementsByTagName('footer') //recuper l'elemento footer
  newTable.innerHTML = "<tr><td>1</td><td>2</td><td>3</td></tr>".repeat(4) //scrive nell'HTML della tabella la struttura di 1 riga con 3 colonne ripetuta per 4 volte
  newTable.style.border = "2px solid #0300c5"  //assegna uno stile al bordo tabella 
  body[0].insertBefore(newTable,footer[0]) //inserisce la nuova table prima del footer
}
console.log("con click su 'NEW TABLE' viene creata una nuova tabella prima del footer");
console.log(" ");

//Esercizio 50
console.log("ESERCIZIO N°50");

function eraseTable(){    
   const arrTable = document.getElementsByTagName('table') //recupera gli elementi table
   const body = document.getElementsByTagName('body') //recupera gli elementi body
   let MaxIndexTable = arrTable.length - 1; //calcola l'indice massimo dell'array di tabelle
   body[0].removeChild(arrTable[MaxIndexTable]) //rimuove dal body la tabella con indice massimo (l'ultima)
}
console.log("con click su 'ERASE LAST TABLE' viene cancellata l'ultima tabella della pagina");
console.log(" ");
